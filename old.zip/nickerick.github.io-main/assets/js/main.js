const button1 = document.getElementById('test1');
const docColor = document.getElementById('proj1');

// console.log(button1);
button1.addEventListener('click', () => {
    // console.log(docColor);
    docColor.style.color = 'green';
});
