This is my personal website. Hosted on new domain at nickerick.com
